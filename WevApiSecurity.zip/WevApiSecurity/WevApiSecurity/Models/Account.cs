﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WevApiSecurity.Models
{
    public class Account
    {
        public string A { get; set; }
        public string B { get; set; }
    }
}