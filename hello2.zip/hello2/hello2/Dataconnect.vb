﻿Imports System.Data.SqlClient
Imports System.Configuration

Public Class Dataconnect
    Private con As SqlConnection

    Public Sub New()
        con = New SqlConnection(ConfigurationManager.ConnectionStrings("hello2.My.MySettings.TemplateConnectionString").ConnectionString)
    End Sub

    Public Function ExecutenonQuery(sqlcmd As SqlCommand) As Integer
        Try
            con.Open()
            sqlcmd.Connection = con
            Return sqlcmd.ExecuteNonQuery()
        Catch generatedExceptionName As Exception
            Return 0
        Finally
            CloseConn()
            CloseCmd(sqlcmd)
        End Try
    End Function

    Public Function ExecuteReader(sqlcmd As SqlCommand) As DataTable
        Dim dr As SqlDataReader
        Dim table As New DataTable
        Try
            con.Open()
            sqlcmd.Connection = con
            dr = sqlcmd.ExecuteReader()
            table.Load(dr)
            Return table
        Catch generatedExceptionName As Exception
            Return table
        Finally
            CloseConn()
            CloseCmd(sqlcmd)
        End Try
    End Function

    Public Sub CloseConn()
        If (con.State <> ConnectionState.Closed) Then
            con.Close()
            con = Nothing
        End If
    End Sub

    Public Sub CloseCmd(cmd As SqlCommand)
        If (cmd IsNot Nothing) Then
            cmd.Dispose()
            cmd = Nothing
        End If
    End Sub

End Class
