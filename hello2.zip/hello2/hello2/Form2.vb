﻿Public Class Form2
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        AcceptButton = Button1
        CancelButton = Button2
    End Sub

    Private Sub TextBox1_KeyUp(sender As Object, e As KeyEventArgs) Handles TextBox1.KeyUp
        If (TextBox1.Text = "hoang") Then
            TextBox1.Clear()
        End If
    End Sub
End Class