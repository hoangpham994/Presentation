﻿Public Class Form3
    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'TemplateDataSet.Device' table. You can move, or remove it, as needed.
        Me.DeviceTableAdapter.Fill(Me.TemplateDataSet.Device)

    End Sub


End Class