﻿Imports System.Data.SqlClient
Imports System.Configuration

Public Class Form4

    Dim connection As SqlConnection =
        New SqlConnection(ConfigurationManager.ConnectionStrings("hello2.My.MySettings.TemplateConnectionString").ConnectionString)
    Dim command As New SqlCommand
    Dim dr As SqlDataReader

    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadDevice()
        LoadListKind()
    End Sub

    Private Sub LoadDevice()

        Dim query As String = "
            select DeviceID,DeviceName,KindName,Available
            from Device,Kind
            Where Device.KindID = Kind.KindID"
        command.CommandText = query
        Dim dataCon As Dataconnect = New Dataconnect
        Dim table As New DataTable
        table = dataCon.ExecuteReader(command)
        dgDevice.DataSource = table

    End Sub

    Private Sub LoadListKind()

        Dim query As String = "Select * from Kind"
        command.CommandText = query
        Dim dataCon As Dataconnect = New Dataconnect
        Dim table As New DataTable
        table = dataCon.ExecuteReader(command)
        cbKind.DisplayMember = "KindName"
        cbKind.ValueMember = "KindID"
        cbKind.DataSource = table

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim number As Double = cbKind.SelectedValue

        If txtName.Text <> "" And txtNumber.Text <> "" And number > 0 Then

            command.CommandText = "insert into Device (DeviceName,KindID,Available) values('" & txtName.Text & "','" & cbKind.SelectedValue & "','" & txtNumber.Text & "')"
            Dim dataCon As Dataconnect = New Dataconnect
            Dim result As Integer = dataCon.ExecutenonQuery(command)

        End If
        LoadDevice()
        txtName.Text = ""
        txtNumber.Text = ""
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim rowIndex As DataGridViewRow = dgDevice.CurrentRow
        Dim deviceID As String = rowIndex.Cells(0).Value

        command.CommandText = "delete from Device where DeviceID='" & deviceID & "'"
        Dim dataCon As Dataconnect = New Dataconnect
        Dim result As Integer = dataCon.ExecutenonQuery(command)
        If result <> 0 Then
            LoadDevice()
        End If

    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        btnCancel.Enabled = True
        btnOK.Enabled = True
        btnEdit.Enabled = False
        txtName.Text = ""
        txtNumber.Text = ""
    End Sub

    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        btnCancel.Enabled = False
        btnOK.Enabled = False
        btnEdit.Enabled = True
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        btnCancel.Enabled = False
        btnOK.Enabled = False
        btnEdit.Enabled = True
    End Sub
End Class

