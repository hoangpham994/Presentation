﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.DeviceIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DeviceNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.KindIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AvailableDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DeviceBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TemplateDataSet = New hello2.TemplateDataSet()
        Me.DeviceTableAdapter = New hello2.TemplateDataSetTableAdapters.DeviceTableAdapter()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DeviceBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TemplateDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DeviceIDDataGridViewTextBoxColumn, Me.DeviceNameDataGridViewTextBoxColumn, Me.KindIDDataGridViewTextBoxColumn, Me.AvailableDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.DeviceBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(23, 12)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(443, 238)
        Me.DataGridView1.TabIndex = 0
        '
        'DeviceIDDataGridViewTextBoxColumn
        '
        Me.DeviceIDDataGridViewTextBoxColumn.DataPropertyName = "DeviceID"
        Me.DeviceIDDataGridViewTextBoxColumn.HeaderText = "DeviceID"
        Me.DeviceIDDataGridViewTextBoxColumn.Name = "DeviceIDDataGridViewTextBoxColumn"
        Me.DeviceIDDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DeviceNameDataGridViewTextBoxColumn
        '
        Me.DeviceNameDataGridViewTextBoxColumn.DataPropertyName = "DeviceName"
        Me.DeviceNameDataGridViewTextBoxColumn.HeaderText = "DeviceName"
        Me.DeviceNameDataGridViewTextBoxColumn.Name = "DeviceNameDataGridViewTextBoxColumn"
        '
        'KindIDDataGridViewTextBoxColumn
        '
        Me.KindIDDataGridViewTextBoxColumn.DataPropertyName = "KindID"
        Me.KindIDDataGridViewTextBoxColumn.HeaderText = "KindID"
        Me.KindIDDataGridViewTextBoxColumn.Name = "KindIDDataGridViewTextBoxColumn"
        '
        'AvailableDataGridViewTextBoxColumn
        '
        Me.AvailableDataGridViewTextBoxColumn.DataPropertyName = "Available"
        Me.AvailableDataGridViewTextBoxColumn.HeaderText = "Available"
        Me.AvailableDataGridViewTextBoxColumn.Name = "AvailableDataGridViewTextBoxColumn"
        '
        'DeviceBindingSource
        '
        Me.DeviceBindingSource.DataMember = "Device"
        Me.DeviceBindingSource.DataSource = Me.TemplateDataSet
        '
        'TemplateDataSet
        '
        Me.TemplateDataSet.DataSetName = "TemplateDataSet"
        Me.TemplateDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DeviceTableAdapter
        '
        Me.DeviceTableAdapter.ClearBeforeFill = True
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(478, 262)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "Form3"
        Me.Text = "Form3"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DeviceBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TemplateDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents TemplateDataSet As TemplateDataSet
    Friend WithEvents DeviceBindingSource As BindingSource
    Friend WithEvents DeviceTableAdapter As TemplateDataSetTableAdapters.DeviceTableAdapter
    Friend WithEvents DeviceIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DeviceNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents KindIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents AvailableDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class
